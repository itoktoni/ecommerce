@extends(Helper::setViewContent())
@section('content')
<div class="row">
    {!! Form::model($model, ['route'=>[$action_code, 'code' =>
    $model->production_work_order_detail_production_work_order_id, 'detail' =>
    $model->production_work_order_detail_item_product_id ],'class'=>'form-horizontal','files'=>true]) !!}
    <div class="panel-body">
        <div class="panel panel-default">
            <header class="panel-heading">
                <h2 class="panel-title">Progress Item : {{ $model->item_product_name }}</h2>
            </header>

            <div class="panel-body line">
                <div class="show">
                    <table class="table table-table table-bordered table-striped table-hover mb-none">
                        <tbody>
                            <tr>
                                <th class="col-lg-2">ID Product</th>
                                <th>{{ $model->item_product_id }}</th>
                                <input type="hidden"
                                    value="{{ $model->production_work_order_detail_production_work_order_id }}"
                                    name="production_work_order_detail_progress_work_order_id">
                                <input type="hidden" value="{{ $model->production_work_order_detail_item_product_id }}"
                                    name="production_work_order_detail_progress_item_product_id">
                            </tr>

                            <tr>
                                <th class="col-lg-2">Work Order</th>
                                <th>{{ $model->production_work_order_detail_production_work_order_id }}</th>
                            </tr>

                            <tr>
                                <th class="col-lg-2">Survey Date</th>
                                <th>
                                    <div class="input-group col-md-3">
                                        <input type="text" name="production_work_order_detail_progress_date"
                                            class="form-control" data-plugin-datepicker value="{{ date('Y-m-d') }}">
                                        <span class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </span>
                                    </div>
                                </th>
                            </tr>

                            <tr>
                                <th class="col-lg-2">Survey Status</th>
                                <th>
                                    <div class="input-group col-md-3">
                                        <select class="form-control" name="production_work_order_detail_progress_status"
                                            id="">
                                            @foreach (Helper::shareStatus($status) as $key => $value)
                                            <option value="{{ $key }}">{{ $value }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </th>
                            </tr>

                            <tr>
                                <th class="col-lg-2">Survey Notes</th>
                                <th
                                    class="{{ $errors->has('production_work_order_detail_progress_notes') ? 'has-error' : ''}}">
                                    <textarea class="form-control" name="production_work_order_detail_progress_notes"
                                        id="" cols="30"
                                        rows="3">{{ old('production_work_order_detail_progress_notes') ?? '' }}</textarea>
                                    {!! $errors->first('production_work_order_detail_progress_notes', '<p
                                        class="help-block">:message</p>') !!}
                                </th>
                            </tr>

                        </tbody>
                    </table>
                </div>

                <div class="show-table">
                    <div class="show">
                        @include($folder.'::page.'.$template.'.progress')
                    </div>
                </div>

            </div>

        </div>
    </div>
    @include($folder.'::page.'.$template.'.action')
    {!! Form::close() !!}
</div>
@endsection