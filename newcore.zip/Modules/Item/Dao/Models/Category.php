<?php

namespace Modules\Item\Dao\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
  protected $table = 'item_category';
  protected $primaryKey = 'item_category_id';
  protected $fillable = [
    'item_category_id',
    'item_category_slug',
    'item_category_name',
    'item_category_description',
    'item_category_created_at',
    'item_category_created_by',
  ];

  public $timestamps = true;
  public $incrementing = true;
  public $rules = [
    'item_category_name' => 'required|min:3',
  ];

  const CREATED_AT = 'item_category_created_at';
  const UPDATED_AT = 'item_category_created_by';

  public $searching = 'item_category_name';
  public $datatable = [
    'item_category_id'          => [false => 'ID'],
    'item_category_name'        => [true => 'Name'],
    'item_category_slug'        => [true => 'Slug'],
    'item_category_description' => [true => 'Description'],
    'item_category_created_at'  => [false => 'Created At'],
    'item_category_created_by'  => [false => 'Updated At'],
  ];

  public $status = [
    '1' => ['Active', 'primary'],
    '0' => ['Not Active', 'danger'],
  ];
}
