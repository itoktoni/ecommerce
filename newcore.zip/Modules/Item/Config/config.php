<?php

return [
    'name' => 'Item'
];
