# Changelog

All notable changes to `LaravelWebConsole` will be documented in this file.

## Version 1.0

### What is new;
- Everything



## Version 1.1

### What is new;
- Code refactoring



## Version 1.2

### What is new;
- Code refactoring



## Version 1.3

### What is new;
- Code refactoring



## Version 1.4

### What is new;
- Bug fix
- Easier manually installation



## Version 1.5

### What is new;
- Bug fix

## Version 1.5.1

### What is new;
- Checked the package on Laravel 5.8.*
- Updated README.md
