<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Po\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Po\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);