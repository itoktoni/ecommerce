<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Forwarder\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Forwarder\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);