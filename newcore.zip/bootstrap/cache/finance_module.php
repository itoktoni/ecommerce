<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Finance\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Finance\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);