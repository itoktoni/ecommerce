document.addEventListener("pjax:error", function(e) {
    console.log(e);
    window.location.replace(e.request.responseURL);
});

document.addEventListener("DOMContentLoaded", function() {
    pjax = new Pjax({
        elements: ["a"],
        selectors: ["body"],
        cacheBust: false
    });
});

$(document).on('click', '#childMenu', function() {
    setTimeout(function() {
        $('html').removeClass('sidebar-left-opened');
    }, 500);
});