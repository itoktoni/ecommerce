@if(config('website.env') == 'local')
@include(Helper::setViewContent('cssdev'))
@else
@include(Helper::setViewContent('csspro'))
@endif
@stack('css')
<link rel="stylesheet" href="{{ Helper::backend('vendor/pnotify/pnotify.custom.css') }}" />
<link rel="stylesheet" href="{{ Helper::backend('stylesheets/theme.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::backend('stylesheets/skins/default.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::backend('stylesheets/theme-custom.min.css') }}">
<link rel="stylesheet" href="{{ Helper::backend('stylesheets/responsive.min.css') }}">