{!! $container !!}

@push('javascript')
{{ $script }}
@endpush