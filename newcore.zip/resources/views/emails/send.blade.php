<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>title send email</title>
</head>
<body>
	Hello saya Email
</body>
</html>