<?php
return [

    'php' => 'product-hunt',
    'zip' => 'archive',
    'rar' => 'archive',
    'json' => 'chain-broken',
    'html' => 'html5',
    'css' => 'css3',
    'env' => 'gear',
    'gitignore' => 'eye-slash',
    'gitattributes' => 'git',
    'lock' => 'lock',
    'xml' => 'code',
    'js' => 'jsfiddle',
    'mix' => 'jsfiddle',
    'config' => 'cogs',
    'ini' => 'cogs',
    'ico' => 'globe',
    'txt' => 'file-text',
    'htaccess' => 'lock',
];
